
#ifndef _STDINT_H
#define _STDINT_H   1
 
#include <ctypes.h>
 
#endif /* stdint.h */