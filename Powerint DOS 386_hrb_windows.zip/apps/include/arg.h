#ifndef _ARG_H
#define _ARG_H
#ifdef __cplusplus
extern "C" {
#endif
int Get_Arg(char *Arg,char *CmdLine,int Count);
int Get_Argc(char *CmdLine);
#ifdef __cplusplus
}
#endif
#endif