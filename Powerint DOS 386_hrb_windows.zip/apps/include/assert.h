#ifndef _ASSERT__
#define _ASSERT__
#define assert(n) 
#endif