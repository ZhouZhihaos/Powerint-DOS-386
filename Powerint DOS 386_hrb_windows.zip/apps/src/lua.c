
#define getenv(s) "?.lua"

#include "lua/m.c"