#define MAKE_LUAC
#define getenv(s) "?.lua"
#include "lua/m.c"