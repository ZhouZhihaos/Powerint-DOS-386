#ifndef __STDLIB
#define __STDLIB
#define NOREAD
#include <dos.h>
#endif