extern "C" {
  #include <dos.h>
}
#include <pvec.hpp>
// 构造函数的实现

